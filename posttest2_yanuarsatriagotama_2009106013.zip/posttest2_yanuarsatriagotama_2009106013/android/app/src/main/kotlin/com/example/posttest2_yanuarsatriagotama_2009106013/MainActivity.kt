package com.example.posttest2_yanuarsatriagotama_2009106013

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
