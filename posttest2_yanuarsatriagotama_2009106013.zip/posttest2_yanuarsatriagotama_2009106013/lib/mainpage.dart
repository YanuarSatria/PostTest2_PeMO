import 'package:flutter/material.dart';

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 105, 245, 243),
      body: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 200,
                height: 250,
                margin: EdgeInsets.only(top: 61),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("assets/elec.png"),
                  ),
                ),
              ),
              Text(
                "Bright your Life\n",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
              ),
              Text(
                "Butuh Barang Elektronik Murah & Berkualitas?\n Datanglah ke Toko Kami Harga & Kualitas Terjamin",
                style: TextStyle(
                  fontSize: 16,
                  color: Color.fromARGB(255, 0, 0, 0),
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    width: 210,
                    height: 250,
                    margin: EdgeInsets.only(top: 61),
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/kipas.png"),
                          ),
                        ),
                      ),
                    Container(
                      width: 210,
                      height: 250,
                      margin: EdgeInsets.only(top: 61),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("assets/setrika.png"),
                            ),
                          ),
                        ),
                    Container(
                      width: 210,
                      height: 250,
                      margin: EdgeInsets.only(top: 61),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage("assets/lampu.png"),
                            ),
                          ),
                        ),
                      ],
                    ),
                
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizeContainer(isActive: true, size: "Kipas"),
                  SizeContainer(size: "Setrika"),
                  SizeContainer(size: "Lampu"),
                ],
              ),
              MyButton()
            ],
          ),
        ],
      ),
    );
  }
}

class SizeContainer extends StatelessWidget {
  const SizeContainer({Key? key, this.isActive = false, required this.size})
      : super(key: key);

  final bool isActive;
  final String size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 85,
      height: 60,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: isActive ? Color(0xFF023E4A) : Colors.transparent,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(
          width: 1,
          color: Color(0xFF023E4A),
        ),
      ),
      child: Text(
        size,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: isActive ? Colors.white : Color(0xFF023E4A),
        ),
      ),
    );
  }
}

class MyButton extends StatelessWidget {
  const MyButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      height: 55,
      margin: EdgeInsets.only(top: 50),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Color(0xFF023E4A),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        "Order Now",
        style: TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}